# -*- coding: utf-8 -*-

# In this project I implemented the first extension which allows the user to 
# select any three rotors out of a list of five in any order. 

# To use this extension simply follow the prompts in the terminal which ask the 
# user to enter the number of first, then second, then third rotor they would 
# like to use. To get the default rotors enter 0, then 1, then 2. 
